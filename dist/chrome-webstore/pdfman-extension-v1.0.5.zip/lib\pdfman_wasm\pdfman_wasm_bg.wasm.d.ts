/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const compute_preview_dimensions: (a: number, b: number, c: number, d: number) => [number, number];
export const compute_render_window_indices: (a: number, b: number, c: number, d: number, e: number) => [number, number];
export const normalize_rotation: (a: number) => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_start: () => void;
